The Configuration Converter utility allows easy conversion of .xml to .binConfig files and back. 
The binary configuration file type is required for Labview RT. If you need to make a quick change 
to a configuration file, this utility will convert the file for you.

The easiest way to use the converter, is to drag and drop either type of file on the converter 
executable. Drag and drop of multiple files at once is also supported. For information on using
the converter utility on the command-line, just pass it the -h option.